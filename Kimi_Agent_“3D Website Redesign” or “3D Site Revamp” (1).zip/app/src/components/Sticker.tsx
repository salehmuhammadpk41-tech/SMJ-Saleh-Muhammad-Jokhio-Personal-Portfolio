interface StickerProps {
  text: string;
  className?: string;
}

/** Rotating circular text badge — the floating sticker accent. */
export function Sticker({ text, className = '' }: StickerProps) {
  return (
    <div className={`relative ${className}`} aria-hidden="true">
      <div className="animate-spin-slow h-full w-full">
        <svg viewBox="0 0 120 120" className="h-full w-full">
          <defs>
            <path
              id="sticker-circle"
              d="M 60,60 m -44,0 a 44,44 0 1,1 88,0 a 44,44 0 1,1 -88,0"
              fill="none"
            />
          </defs>
          <circle cx="60" cy="60" r="59" className="fill-chart" />
          <circle cx="60" cy="60" r="30" fill="none" strokeWidth="1" className="stroke-ink/30" />
          <text className="fill-ink font-mono" style={{ fontSize: 10.5, letterSpacing: 2.2 }}>
            <textPath href="#sticker-circle">{text}</textPath>
          </text>
        </svg>
      </div>
      <div className="absolute inset-0 flex items-center justify-center">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" className="text-ink">
          <path
            d="M12 3v18m0 0l-6-6m6 6l6-6"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </div>
    </div>
  );
}
