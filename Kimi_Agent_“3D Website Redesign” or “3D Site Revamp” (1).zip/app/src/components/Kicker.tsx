interface KickerProps {
  text: string;
  dark?: boolean;
  className?: string;
}

/** Pill-shaped section label with pulse dot. */
export function Kicker({ text, dark = false, className = '' }: KickerProps) {
  return (
    <span
      className={`inline-flex items-center gap-2.5 rounded-full border px-4 py-1.5 font-mono text-[11px] sm:text-xs font-medium uppercase tracking-[0.14em] ${
        dark
          ? 'border-paper/25 bg-paper/10 text-paper'
          : 'border-ink/15 bg-ink/[0.04] text-ink'
      } ${className}`}
    >
      <span
        className={`h-1.5 w-1.5 rounded-full animate-pulse-dot ${
          dark ? 'bg-chart' : 'bg-ink'
        }`}
      />
      {text}
    </span>
  );
}
