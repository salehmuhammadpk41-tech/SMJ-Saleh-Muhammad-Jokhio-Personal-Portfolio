export const profile = {
  name: 'Saleh Muhammad Jokhio',
  shortName: 'Saleh Muhammad',
  roles: ['Student', 'Digital Creator', 'Creative Technologist'],
  badge: 'Personalized • Modern • Human',
  quote:
    'A curious and creative student with a growing passion for technology, design, and digital creation. I enjoy learning new skills, exploring modern tools, and turning ideas into practical digital experiences that are useful, simple, and visually engaging.',
  status: 'Student & Digital Creator',
  coreInterests:
    'Web Design • Coding • UI/UX • Graphic Design • Digital Content • Productivity Solutions',
  workingStyle: 'Curious • Creative • Practical • Detail-Oriented • User-Focused',
  professionalProfile: 'Student • Digital Creator • Creative Technologist',
};

export const heroFeatures = [
  { title: 'Creative Design', desc: 'Modern aesthetics, UI/UX & graphics.' },
  { title: 'Practical Code', desc: 'Responsive, clean & reliable build.' },
  { title: 'Continuous Growth', desc: 'Discipline, learning & craft.' },
];

export const buildChips = [
  { label: 'Website', tag: '+ Website' },
  { label: 'Web Application', tag: '+ Web App' },
  { label: 'Android App', tag: '+ Android App' },
  { label: 'Online Tool', tag: '+ Online Tool' },
  { label: 'UI/UX Design', tag: '+ UI/UX Design' },
  { label: 'Graphic Design', tag: '+ Graphic Design' },
];

export const heroQuote = 'Turning your idea into a clean, modern digital reality.';

export const aboutProcess =
  'Discover the idea → Understand the purpose → Plan the experience → Design the solution → Build and develop → Test and refine';

export const stats = [
  { value: '11+', label: 'Studio Service Areas' },
  { value: '8', label: 'Verified Technical Skills' },
  { value: '6-Stage', label: 'Working Methodology' },
  { value: '100%', label: 'Dedicated Craft' },
];

export const education = [
  {
    level: 'Completed Secondary School Education',
    school: 'Modern Millat High School',
    grade: 'A Grade',
    status: 'Passed',
    certificate: 'Secondary School Certificate (SSC) / Matriculation',
    group: 'Science Group',
    details: ['Class 9 / SSC Part 1', 'Class 10 / SSC Part 2'],
  },
  {
    level: 'Completed Higher Secondary Education',
    school: 'Government Degree College Konkar Village',
    grade: 'A Grade',
    status: 'Passed',
    certificate: 'Higher Secondary Certificate (HSC) / Intermediate',
    group: 'Pre-Engineering',
    details: ['1st Year', '2nd Year'],
  },
];

export const certificates = [
  {
    provider: 'Malaysian Learning Hub',
    title: 'Microsoft Office Complete Course',
    tag: 'Training Certificate',
    status: 'Training Completed • Certificate Received',
    coverage: ['Introduction to IT', 'MS Word', 'MS Excel', 'MS PowerPoint', 'Internet'],
  },
  {
    provider: 'Malaysian Learning Hub',
    title: 'Website Designing for Everyone',
    tag: 'Website Design Training Certificate',
    status: 'Training Completed • Certificate Received',
    coverage: [
      'Adobe Photoshop',
      'HTML5',
      'CSS',
      'jQuery',
      'Bootstrap',
      'SEO',
      'Domain & Hosting',
      'Final Project',
    ],
  },
];

export const skills = [
  {
    num: '01',
    name: 'HTML',
    desc: 'Semantic markup, structured pages, accessible organization, and modern web standards.',
  },
  {
    num: '02',
    name: 'CSS',
    desc: 'Modern layouts, Flexbox, CSS Grid, responsive styling, spacing, typography, and interface design.',
  },
  {
    num: '03',
    name: 'Basic JavaScript',
    desc: 'Interactive elements, DOM scripting, dynamic behavior, and basic logic flows.',
  },
  {
    num: '04',
    name: 'Web Design',
    desc: 'Modern visual aesthetics, typography, layouts, components, and digital presentation.',
  },
  {
    num: '05',
    name: 'Responsive Web Design',
    desc: 'Mobile, tablet, laptop, and desktop fluid adaptability without clipping or overflow.',
  },
  {
    num: '06',
    name: 'UI Design',
    desc: 'User-interface components, spacing rhythm, hierarchy, navigation, and clean visual systems.',
  },
  {
    num: '07',
    name: 'Website Structure',
    desc: 'Logical page organization, reusable sections, structured content, and clean architecture.',
  },
  {
    num: '08',
    name: 'Mobile-Friendly Design',
    desc: 'Touch-friendly layouts, compact interfaces, responsive navigation, and mobile usability.',
  },
];

export const tools = [
  {
    num: '01',
    name: 'Google AI Studio',
    role: 'AI-assisted development, experimentation, prototyping, and digital project building.',
    category: 'AI Development',
  },
  {
    num: '02',
    name: 'Google Stitch',
    role: 'Interface concepts, UI/UX design, layouts, and digital product visualization.',
    category: 'UI/UX Design',
  },
  {
    num: '03',
    name: 'ChatGPT',
    role: 'Ideas, coding, planning, content creation, problem-solving, and project assistance.',
    category: 'Problem Solving & Development',
  },
  {
    num: '04',
    name: 'Claude',
    role: 'Development assistance, writing, analysis, planning, and project support.',
    category: 'Analysis & Project Support',
  },
  {
    num: '05',
    name: 'Pinterest',
    role: 'Design inspiration, visual references, creative exploration, and mood references.',
    category: 'Visual Inspiration',
  },
];

export const strengths = [
  'Continuous Learning',
  'Creativity',
  'Digital Productivity',
  'Communication',
  'Organization',
  'Attention to Detail',
  'Problem-Solving',
  'Personal Development',
  'Adaptability',
  'Structured Thinking',
  'Practical Learning',
  'Digital Creativity',
];

export const services = [
  {
    title: 'Website Development',
    desc: 'Modern, responsive, professional websites for personal, business, and corporate needs.',
    items: [
      'Personal Websites & Portfolios',
      'Corporate & Business Sites',
      'Landing Pages & Conversion Funnels',
      'Custom Web Architecture',
    ],
  },
  {
    title: 'Web Applications',
    desc: 'Interactive web applications with useful features, forms, dashboards, and custom functionality.',
    items: [
      'Interactive Platforms',
      'Dashboards & Admin Panels',
      'Forms & User Portals',
      'Custom Business Logic',
    ],
  },
  {
    title: 'Android Apps',
    desc: 'Mobile applications, utility apps, interactive applications, and custom Android solutions.',
    items: [
      'Android Applications',
      'Mobile Utilities & Tools',
      'Interactive Mobile Apps',
      'App-Ready Custom Projects',
    ],
  },
  {
    title: 'Online Tools',
    desc: 'Custom online tools designed for productivity and everyday digital needs.',
    items: [
      'Calculators & Converters',
      'Data & Text Generators',
      'PDF & Document Tools',
      'Online Utilities & Productivity',
    ],
  },
  {
    title: 'UI/UX Design',
    desc: 'Clean, modern, responsive interfaces for desktop, tablet, and mobile.',
    items: [
      'Modern Interface Layouts',
      'Mobile-First Touch Systems',
      'Design Systems & Tokens',
      'Interactive Prototypes',
    ],
  },
  {
    title: 'Graphic & Creative Design',
    desc: 'Creative Canva-style digital designs for personal, professional, business, and social media.',
    items: [
      'Logos & Brand Identity',
      'Flyers, Posters & Brochures',
      'Certificates & Invitations',
      'Thumbnails, Banners & Menus',
    ],
  },
  {
    title: 'CV & Resume Design',
    desc: 'Professional CV and resume designs for students, professionals, job seekers, and businesses.',
    items: [
      'Professional Resumes',
      'Modern CV Layouts',
      'ATS-Friendly Structuring',
      'Student & Executive Formats',
    ],
  },
  {
    title: 'Business & Corporate Design',
    desc: 'Professional business materials designed for organizations and individuals.',
    items: [
      'Company Profiles & Decks',
      'Letterheads & Invoices',
      'Employee ID Cards',
      'Proposals & Certificates',
    ],
  },
  {
    title: 'Social Media Design',
    desc: 'Creative digital content for major social platforms.',
    items: [
      'Instagram Posts & Stories',
      'Facebook Banners & Ads',
      'Digital & Channel Thumbnails',
      'LinkedIn Creatives',
    ],
  },
  {
    title: 'Custom Digital Projects',
    desc: 'Unique digital projects developed according to specific requirements.',
    items: [
      'Tailored Digital Solutions',
      'Bespoke Software Workflows',
      'Specialized Automation',
      'Unique Implementations',
    ],
  },
  {
    title: 'Digital Productivity',
    desc: 'Organization tools, workplace utilities, task and flow systems for maximum efficiency.',
    items: [
      'Digital Organization Tools',
      'Workplace Utilities',
      'Task & Flow Systems',
      'Efficiency Boosters',
    ],
  },
];

export const processSteps = [
  {
    num: '01',
    title: 'Understand',
    desc: "Deeply understand the client's vision, core objective, specific requirements, and aesthetic expectations.",
  },
  {
    num: '02',
    title: 'Organize',
    desc: 'Systematically organize requirements, information architecture, and formulate the optimal digital solution roadmap.',
  },
  {
    num: '03',
    title: 'Design',
    desc: 'Design the visual layout, user-friendly interface, typography hierarchy, and intuitive workflow experience.',
  },
  {
    num: '04',
    title: 'Build',
    desc: 'Develop the website, application, tool, graphic design, or bespoke digital code with strict modern standards.',
  },
  {
    num: '05',
    title: 'Test',
    desc: 'Thoroughly review functionality, mobile responsiveness, tablet usability, typography legibility, and cross-browser stability.',
  },
  {
    num: '06',
    title: 'Deliver',
    desc: 'Provide an organized, reliable, future-proof, and usable final product delivered directly on schedule.',
  },
];

export const ideaToExperience = 'Explore → Understand → Imagine → Design → Build → Refine';

export const projects = [
  {
    id: 'vaultkey',
    num: '01',
    title: 'VaultKey',
    category: 'VaultKey Project',
    tagline: 'Your passwords. One secure vault.',
    desc: 'Securely store, organize and manage passwords, notes and sensitive information in one place.',
    url: 'https://vaultkey.ai.studio/',
  },
  {
    id: 'toolhub',
    num: '02',
    title: 'ToolHub',
    category: 'Team / Tools Project',
    tagline: '614 free online tools, in one place.',
    desc: 'An all-in-one online tools platform with 614 useful tools across multiple categories — simple, fast, and easy-to-use solutions in one place.',
    url: 'https://remixtoolhub.ai.studio/',
  },
  {
    id: 'smj',
    num: '03',
    title: 'SMJ Portfolio',
    category: 'Personal Portfolio',
    tagline: 'The official digital portfolio.',
    desc: 'Official digital portfolio of Saleh Muhammad Jokhio — web design, coding, graphic design, and digital productivity.',
    url: 'https://smjportfolio.ai.studio/',
  },
];

export const contact = {
  primaryEmail: 'salehjokhio646@gmail.com',
  primaryLabel: 'Direct Inquiries & Projects',
  alternateEmail: 'salehmuhammadpk41@gmail.com',
  alternateLabel: 'Studio Dispatch Alternate',
  hours: '8:00 AM – 10:00 PM',
  response: 'Within 24 Hours',
  facebook: 'https://www.facebook.com',
  linkedin: 'https://www.linkedin.com',
};

export const contactSubjects = [
  'Website',
  'Portfolio',
  'Online Tools',
  'UI/UX Design',
  'Graphic & Creative Design',
  'CV & Resume Design',
  'Business & Corporate Design',
  'Social Media Design',
  'Custom Digital Projects',
];

export const navItems = [
  { id: 'home', label: 'Home' },
  { id: 'about', label: 'About' },
  { id: 'skills', label: 'Skills' },
  { id: 'services', label: 'Services' },
  { id: 'process', label: 'Process' },
  { id: 'projects', label: 'Projects' },
  { id: 'contact', label: 'Contact' },
];
