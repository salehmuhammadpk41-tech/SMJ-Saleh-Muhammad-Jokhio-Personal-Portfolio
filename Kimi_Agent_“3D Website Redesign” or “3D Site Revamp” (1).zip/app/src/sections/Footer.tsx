import { useState, type FormEvent } from 'react';
import { ArrowUpRight, Facebook, Linkedin, Mail } from 'lucide-react';
import { navItems, contact, profile } from '../data/content';

export function Footer() {
  const [email, setEmail] = useState('');

  const go = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });

  const subscribe = (e: FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;
    window.location.href = `mailto:${contact.primaryEmail}?subject=${encodeURIComponent(
      'Subscribe to Updates'
    )}&body=${encodeURIComponent(`Please subscribe ${email} to updates.`)}`;
    setEmail('');
  };

  return (
    <footer className="bg-ink px-4 pb-10 pt-4 text-paper sm:px-8">
      <div className="mx-auto max-w-6xl border-t border-paper/10 pt-12">
        <div className="grid grid-cols-1 items-start gap-10 pb-12 md:grid-cols-2 lg:grid-cols-12">
          {/* brand */}
          <div className="lg:col-span-5">
            <button
              onClick={() => go('home')}
              className="flex items-center gap-2 font-display text-lg font-bold tracking-tight cursor-pointer"
            >
              <span className="flex h-7 w-7 items-center justify-center rounded-full bg-chart font-mono text-xs font-bold text-ink">
                S
              </span>
              {profile.shortName}
            </button>
            <p className="mt-4 max-w-sm text-sm leading-relaxed text-paper/65">
              Student • Digital Creator • Creative Technologist — turning ideas into clean, modern,
              useful digital experiences.
            </p>
            <div className="mt-5 flex gap-2">
              <a
                href={contact.facebook}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Facebook"
                className="flex h-10 w-10 items-center justify-center rounded-full border border-paper/15 bg-paper/5 transition-colors hover:bg-paper/15"
              >
                <Facebook className="h-4 w-4" />
              </a>
              <a
                href={contact.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="LinkedIn"
                className="flex h-10 w-10 items-center justify-center rounded-full border border-paper/15 bg-paper/5 transition-colors hover:bg-paper/15"
              >
                <Linkedin className="h-4 w-4" />
              </a>
              <a
                href={`mailto:${contact.primaryEmail}`}
                aria-label="Email"
                className="flex h-10 w-10 items-center justify-center rounded-full border border-paper/15 bg-paper/5 transition-colors hover:bg-paper/15"
              >
                <Mail className="h-4 w-4" />
              </a>
            </div>
          </div>

          {/* nav */}
          <div className="lg:col-span-3">
            <div className="font-mono text-[10px] font-semibold uppercase tracking-widest text-paper/50">
              Explore
            </div>
            <div className="mt-4 flex flex-col items-start gap-2.5">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => go(item.id)}
                  className="link-underline text-sm font-medium text-paper/80 transition-colors hover:text-paper cursor-pointer"
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          {/* subscribe */}
          <div className="lg:col-span-4">
            <div className="font-mono text-[10px] font-semibold uppercase tracking-widest text-paper/50">
              Stay Updated
            </div>
            <p className="mt-4 text-sm leading-relaxed text-paper/65">
              Subscribe to updates on new projects, tools, and digital work.
            </p>
            <form onSubmit={subscribe} className="mt-4 flex gap-2">
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@email.com"
                className="min-h-[44px] w-full rounded-full border border-paper/15 bg-paper/5 px-4 text-sm text-paper outline-none placeholder:text-paper/40 focus:border-chart"
              />
              <button
                type="submit"
                aria-label="Subscribe"
                className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-chart text-ink transition-transform duration-200 hover:scale-105 cursor-pointer"
              >
                <ArrowUpRight className="h-4 w-4" />
              </button>
            </form>
          </div>
        </div>

        <div className="flex flex-col items-center justify-between gap-3 border-t border-paper/10 pt-7 text-xs text-paper/55 md:flex-row">
          <div>© 2026 Saleh Muhammad. All rights reserved.</div>
          <div className="text-center text-[11px] text-paper/45">
            Designed, Developed &amp; Maintained by Saleh Muhammad • Portfolio &amp; Digital Services
          </div>
        </div>
      </div>
    </footer>
  );
}
