import { useRef, useState, type CSSProperties } from 'react';
import { ArrowUpRight, Sparkles, Check } from 'lucide-react';
import { Kicker } from '../components/Kicker';
import { Sticker } from '../components/Sticker';
import { profile, heroFeatures, buildChips, heroQuote } from '../data/content';

/* ---------- code-drawn mini cards for the 3D fan ---------- */
const fanCards = [
  { title: 'Web Design', tone: 'bg-chart', bars: ['w-3/4', 'w-1/2', 'w-2/3'], rotate: '-14deg', y: '26px', z: -60, x: '-148%' },
  { title: 'UI / UX', tone: 'bg-mint', bars: ['w-2/3', 'w-3/4', 'w-1/3'], rotate: '-7deg', y: '8px', z: -20, x: '-76%' },
  { title: 'Code', tone: 'bg-ink', bars: ['w-1/2', 'w-2/3', 'w-3/4'], rotate: '0deg', y: '0px', z: 30, x: '0%' },
  { title: 'Apps', tone: 'bg-brick', bars: ['w-3/4', 'w-1/3', 'w-1/2'], rotate: '7deg', y: '8px', z: -20, x: '76%' },
  { title: 'Tools', tone: 'bg-paper-3', bars: ['w-1/3', 'w-3/4', 'w-2/3'], rotate: '14deg', y: '26px', z: -60, x: '148%' },
];

function FanCard({ card, index }: { card: (typeof fanCards)[number]; index: number }) {
  const dark = card.tone === 'bg-ink';
  return (
    <div
      className="preserve-3d absolute left-1/2 top-1/2 w-32 sm:w-40 md:w-44"
      style={
        {
          transform: `translate(-50%, -50%) translateX(${card.x}) translateY(${card.y}) translateZ(${card.z}px) rotate(${card.rotate})`,
          zIndex: 10 - Math.abs(index - 2),
        } as CSSProperties
      }
    >
      <div
        className="animate-floaty rounded-2xl border border-ink/10 bg-paper-card p-3 shadow-float"
        style={{ '--float-dur': `${5.5 + index * 0.7}s`, '--float-delay': `${index * 0.6}s` } as CSSProperties}
      >
        <div className="mb-2.5 flex items-center gap-1">
          <span className="h-1.5 w-1.5 rounded-full bg-ink/20" />
          <span className="h-1.5 w-1.5 rounded-full bg-ink/20" />
          <span className="h-1.5 w-1.5 rounded-full bg-ink/20" />
        </div>
        <div className={`mb-2.5 flex h-14 sm:h-16 items-center justify-center rounded-xl ${card.tone}`}>
          <span
            className={`font-mono text-[10px] sm:text-[11px] font-semibold uppercase tracking-widest ${
              dark ? 'text-chart' : 'text-ink'
            }`}
          >
            {card.title}
          </span>
        </div>
        <div className="space-y-1.5">
          {card.bars.map((w, i) => (
            <div key={i} className={`h-1.5 rounded-full bg-ink/10 ${w}`} />
          ))}
        </div>
      </div>
    </div>
  );
}

export function Hero() {
  const ref = useRef<HTMLElement>(null);
  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  const [selected, setSelected] = useState('');

  const onMove = (e: React.MouseEvent) => {
    const rect = ref.current?.getBoundingClientRect();
    if (!rect) return;
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;
    setTilt({ x, y });
  };

  const go = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });

  return (
    <section
      id="home"
      ref={ref}
      onMouseMove={onMove}
      onMouseLeave={() => setTilt({ x: 0, y: 0 })}
      className="relative overflow-hidden px-4 pt-32 sm:pt-40 pb-16 sm:px-8"
    >
      {/* soft radial glow */}
      <div
        className="pointer-events-none absolute left-1/2 top-0 -z-10 h-[720px] w-[1100px] -translate-x-1/2 rounded-full opacity-70"
        style={{ background: 'radial-gradient(closest-side, rgba(251,247,236,0.95), rgba(242,236,220,0))' }}
      />

      <div className="mx-auto max-w-6xl">
        {/* ------- typographic stack ------- */}
        <div className="relative z-10 flex flex-col items-center text-center">
          <Kicker text={profile.badge} className="reveal is-visible" />

          <h1 className="mt-7 max-w-4xl text-balance font-display text-[13vw] sm:text-6xl md:text-7xl lg:text-[5.4rem] font-extrabold leading-[1.02] tracking-[-0.03em]">
            Creating, Learning &amp;{' '}
            <em className="font-serif font-normal italic tracking-[-0.01em]">Building</em>
            <br className="hidden sm:block" /> in the Digital{' '}
            <span className="relative inline-block">
              World
              <span className="absolute inset-x-0 bottom-1 sm:bottom-2 -z-10 h-3 sm:h-4 -rotate-1 rounded-sm bg-chart" />
            </span>
          </h1>

          <p className="mt-6 flex flex-wrap items-center justify-center gap-x-3 gap-y-1.5 font-mono text-[11px] sm:text-xs font-medium uppercase tracking-[0.18em] text-ink-mute">
            {profile.roles.map((r, i) => (
              <span key={r} className="flex items-center gap-3">
                {i > 0 && <span className="h-1 w-1 rounded-full bg-ink/30" />}
                {r}
              </span>
            ))}
          </p>

          <p className="mt-6 max-w-xl text-balance text-[15px] sm:text-base leading-relaxed text-ink-soft">
            I enjoy turning ideas into modern digital experiences — clean, useful, responsive and
            easy to use — while continuously learning and combining creativity, technology and
            practical problem-solving.
          </p>

          <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={() => go('contact')}
              className="btn-arrow group inline-flex min-h-[46px] items-center gap-2.5 rounded-full bg-ink px-7 py-3 text-sm font-semibold text-paper transition-all duration-300 hover:bg-transparent hover:text-ink hover:shadow-[inset_0_0_0_1.5px_#0e2a22] cursor-pointer"
            >
              Start a project
              <span className="relative inline-flex h-4 w-4 overflow-hidden">
                <ArrowUpRight className="arrow-main h-4 w-4" />
                <ArrowUpRight className="arrow-clone h-4 w-4" />
              </span>
            </button>
            <button
              onClick={() => go('projects')}
              className="inline-flex min-h-[46px] items-center gap-2 rounded-full border border-ink/15 bg-paper-card px-7 py-3 text-sm font-semibold text-ink transition-all duration-300 hover:border-ink/40 card-lift cursor-pointer"
            >
              Explore my work
            </button>
          </div>
        </div>

        {/* ------- 3D fan of floating cards ------- */}
        <div className="relative mt-14 sm:mt-16 sm:pb-40">
          <div className="origin-center scale-[0.68] sm:scale-100 transition-transform duration-500">
            <div
              className="perspective-1200 relative mx-auto h-56 sm:h-64 md:h-72 max-w-4xl transition-transform duration-300 ease-out"
            style={{ transform: `rotateX(${-tilt.y * 5}deg) rotateY(${tilt.x * 6}deg)` }}
          >
            <div className="preserve-3d absolute inset-0">
              {fanCards.map((card, i) => (
                <FanCard key={card.title} card={card} index={i} />
              ))}
            </div>

            {/* floating role chips */}
            <div
              className="absolute left-[4%] sm:left-[8%] top-2 z-20 animate-floaty"
              style={{ '--float-dur': '7s', transform: `translate(${tilt.x * -14}px, ${tilt.y * -10}px)` } as CSSProperties}
            >
              <span className="inline-flex items-center gap-1.5 rounded-full bg-ink px-3.5 py-1.5 text-[11px] font-semibold text-chart shadow-lift">
                <Sparkles className="h-3 w-3" /> Student
              </span>
            </div>
            <div
              className="absolute right-[2%] sm:right-[5%] top-24 z-20 animate-floaty"
              style={{ '--float-dur': '6.2s', '--float-delay': '0.8s', transform: `translate(${tilt.x * -20}px, ${tilt.y * -14}px)` } as CSSProperties}
            >
              <span className="inline-flex items-center rounded-full border border-ink/10 bg-paper-card px-3.5 py-1.5 text-[11px] font-semibold text-ink shadow-lift">
                Creative Technologist
              </span>
            </div>

            {/* rotating sticker */}
            <div className="absolute -top-10 right-[26%] sm:right-[24%] z-30 hidden sm:block">
              <Sticker text="OPEN TO PROJECTS • DIGITAL CREATOR • " className="h-24 w-24 md:h-28 md:w-28 drop-shadow-xl" />
            </div>
            </div>
          </div>

          {/* interactive build widget */}
          <div className="relative z-20 mx-auto mt-8 max-w-md sm:absolute sm:bottom-2 sm:right-0 sm:mt-0 sm:w-[380px]">
            <div className="rounded-3xl border border-paper/15 bg-ink p-5 text-paper shadow-deep">
              <div className="mb-3 flex items-center justify-between">
                <span className="text-xs font-medium text-paper/90">What would you like to build?</span>
                <span className="font-mono text-[10px] font-semibold uppercase tracking-widest text-chart">
                  Interactive
                </span>
              </div>
              <div className="mb-4 flex flex-wrap gap-1.5">
                {buildChips.map((chip) => {
                  const on = selected === chip.label;
                  return (
                    <button
                      key={chip.label}
                      onClick={() => setSelected(on ? '' : chip.label)}
                      className={`inline-flex min-h-[32px] items-center gap-1.5 rounded-full px-3 py-1 text-[11px] font-medium transition-all duration-200 cursor-pointer ${
                        on
                          ? 'bg-chart font-semibold text-ink'
                          : 'border border-paper/15 bg-paper/10 text-paper/80 hover:bg-paper/20'
                      }`}
                    >
                      {on && <Check className="h-3 w-3" />}
                      {chip.tag}
                    </button>
                  );
                })}
              </div>
              <div className="flex items-center justify-between gap-3 border-t border-paper/10 pt-3">
                <p className="font-serif text-[13px] italic leading-snug text-paper/70">“{heroQuote}”</p>
                <button
                  onClick={() => go('contact')}
                  className="shrink-0 rounded-full bg-chart px-4 py-2 text-[11px] font-bold uppercase tracking-wide text-ink transition-transform duration-200 hover:scale-105 cursor-pointer"
                >
                  Start
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* ------- three feature points ------- */}
        <div className="mx-auto mt-24 sm:mt-28 grid max-w-4xl grid-cols-1 gap-4 sm:grid-cols-3">
          {heroFeatures.map((f, i) => (
            <div
              key={f.title}
              className="card-lift rounded-3xl border border-ink/10 bg-paper-card p-6"
              style={{ transitionDelay: `${i * 40}ms` }}
            >
              <div className="mb-3 font-mono text-[11px] font-semibold uppercase tracking-widest text-ink-mute">
                0{i + 1}
              </div>
              <h3 className="font-display text-lg font-bold tracking-tight">{f.title}</h3>
              <p className="mt-1.5 text-sm leading-relaxed text-ink-soft">{f.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
