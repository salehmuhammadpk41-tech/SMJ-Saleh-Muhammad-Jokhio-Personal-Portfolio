import { ArrowUpRight } from 'lucide-react';
import { Kicker } from '../components/Kicker';
import { Reveal } from '../components/Reveal';
import { services, ideaToExperience } from '../data/content';

export function Services() {
  const go = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });

  return (
    <section id="services" className="relative px-4 py-20 sm:px-8 sm:py-28">
      <div className="mx-auto max-w-6xl">
        <Reveal>
          <Kicker text="Ideas into Digital Experiences" />
        </Reveal>
        <div className="mt-6 grid grid-cols-1 gap-8 lg:grid-cols-12 lg:items-end">
          <Reveal delay={60} className="lg:col-span-7">
            <h2 className="text-balance font-display text-4xl font-extrabold leading-[1.06] tracking-[-0.025em] sm:text-5xl">
              Designing With Curiosity.{' '}
              <em className="font-serif font-normal italic">Building With Purpose.</em>
            </h2>
          </Reveal>
          <Reveal delay={120} className="lg:col-span-5">
            <p className="text-[15px] leading-relaxed text-ink-soft">
              I explore the space where technology, creativity, and design come together — creating
              websites, digital tools, user interfaces, coded experiences, visual designs, and
              practical digital solutions.
            </p>
          </Reveal>
        </div>

        <Reveal delay={100}>
          <div className="mt-8 flex flex-wrap items-center gap-2 rounded-3xl border border-ink/10 bg-paper-card p-5 shadow-lift">
            <span className="mr-1 font-mono text-[11px] font-semibold uppercase tracking-widest text-ink-mute">
              From Idea to Experience
            </span>
            {ideaToExperience.split('→').map((step, i, arr) => (
              <span key={i} className="flex items-center gap-2">
                <span className="rounded-full bg-ink px-3 py-1.5 text-[11px] font-semibold text-paper">
                  {step.trim()}
                </span>
                {i < arr.length - 1 && <span className="text-ink/30">→</span>}
              </span>
            ))}
          </div>
        </Reveal>

        <div className="mt-12 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((s, i) => (
            <Reveal key={s.title} delay={(i % 3) * 60}>
              <div className="card-lift group flex h-full flex-col rounded-3xl border border-ink/10 bg-paper-card p-6">
                <div className="flex items-start justify-between gap-3">
                  <span className="font-mono text-xs font-semibold text-ink-mute">
                    {String(i + 1).padStart(2, '0')}
                  </span>
                  <button
                    onClick={() => go('contact')}
                    aria-label={`Request ${s.title}`}
                    className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-ink/10 text-ink transition-all duration-300 group-hover:bg-ink group-hover:text-chart cursor-pointer"
                  >
                    <ArrowUpRight className="h-3.5 w-3.5" />
                  </button>
                </div>
                <h3 className="mt-4 font-display text-xl font-bold tracking-tight">{s.title}</h3>
                <p className="mt-2 text-[13px] leading-relaxed text-ink-soft">{s.desc}</p>
                <ul className="mt-4 space-y-2 border-t border-ink/10 pt-4">
                  {s.items.map((item) => (
                    <li key={item} className="flex items-center gap-2.5 text-[13px] font-medium text-ink">
                      <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-chart shadow-[0_0_0_2px_rgba(14,42,34,0.08)]" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
