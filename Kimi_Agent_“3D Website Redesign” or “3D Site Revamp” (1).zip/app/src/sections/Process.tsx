import { Kicker } from '../components/Kicker';
import { Reveal } from '../components/Reveal';
import { processSteps } from '../data/content';

export function Process() {
  return (
    <section id="process" className="relative px-4 py-20 sm:px-8 sm:py-28">
      <div className="mx-auto max-w-6xl">
        <Reveal>
          <Kicker text="How I work • Methodology" />
        </Reveal>
        <Reveal delay={60}>
          <h2 className="mt-6 max-w-2xl text-balance font-display text-4xl font-extrabold leading-[1.06] tracking-[-0.025em] sm:text-5xl">
            A <em className="font-serif font-normal italic">6-Stage</em> Project Process
          </h2>
          <p className="mt-4 max-w-lg text-[15px] leading-relaxed text-ink-soft">
            Every idea is turned into reality through an orderly, transparent, and disciplined
            sequence.
          </p>
        </Reveal>

        <div className="mt-12 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {processSteps.map((step, i) => (
            <Reveal key={step.num} delay={(i % 3) * 70}>
              <div className="card-lift group relative h-full overflow-hidden rounded-3xl border border-ink/10 bg-paper-card p-6">
                <div className="absolute -right-4 -top-6 font-display text-[6rem] font-extrabold leading-none tracking-tighter text-ink/[0.05] transition-colors duration-300 group-hover:text-ink/[0.09] select-none">
                  {step.num}
                </div>
                <div className="relative">
                  <span className="inline-flex h-9 items-center rounded-full bg-ink px-3.5 font-mono text-xs font-semibold text-chart">
                    {step.num}
                  </span>
                  <h3 className="mt-4 font-display text-xl font-bold tracking-tight">{step.title}</h3>
                  <p className="mt-2 text-[13px] leading-relaxed text-ink-soft">{step.desc}</p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
