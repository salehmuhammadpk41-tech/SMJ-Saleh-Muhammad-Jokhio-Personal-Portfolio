import { GraduationCap, BadgeCheck, Quote } from 'lucide-react';
import { Kicker } from '../components/Kicker';
import { Reveal } from '../components/Reveal';
import { profile, aboutProcess, stats, education, certificates } from '../data/content';

export function About() {
  return (
    <section id="about" className="relative px-4 py-20 sm:px-8 sm:py-28">
      <div className="mx-auto max-w-6xl">
        <Reveal>
          <Kicker text="Who I am • About Saleh Muhammad" />
        </Reveal>
        <Reveal delay={60}>
          <h2 className="mt-6 max-w-3xl text-balance font-display text-4xl font-extrabold leading-[1.06] tracking-[-0.025em] sm:text-5xl">
            Learning, Creating, and Building in the{' '}
            <em className="font-serif font-normal italic">Digital World</em>
          </h2>
        </Reveal>

        <div className="mt-12 grid grid-cols-1 gap-8 lg:grid-cols-12 lg:gap-12">
          {/* left: narrative */}
          <div className="lg:col-span-7">
            <Reveal>
              <p className="text-[15px] sm:text-base leading-relaxed text-ink-soft">
                I’m <strong className="font-semibold text-ink">Saleh Muhammad Jokhio</strong>, a
                student and digital creator with a growing interest in technology, web development,
                UI/UX, coding, graphic design, digital content, and productivity solutions.
              </p>
              <p className="mt-4 text-[15px] sm:text-base leading-relaxed text-ink-soft">
                I enjoy turning ideas into practical digital work — whether it is designing a
                website, creating a digital experience, developing a useful tool, preparing a
                professional design, or exploring new technologies. I’m always looking for
                opportunities to learn, experiment, improve my skills, and build something useful.
              </p>
              <p className="mt-4 text-[15px] sm:text-base leading-relaxed text-ink-soft">
                I believe meaningful digital work comes from combining creativity, curiosity,
                practical thinking, continuous learning, and attention to detail. My goal is to
                keep growing as a digital creator while creating work that is modern, useful,
                responsive, and genuinely valuable.
              </p>
            </Reveal>

            {/* creative process chain */}
            <Reveal delay={100}>
              <div className="mt-8 rounded-3xl border border-ink/10 bg-paper-card p-6 shadow-lift">
                <div className="mb-3 font-mono text-[11px] font-semibold uppercase tracking-widest text-ink-mute">
                  My Creative Process
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  {aboutProcess.split('→').map((step, i, arr) => (
                    <span key={i} className="flex items-center gap-2">
                      <span className="rounded-full bg-ink/[0.05] border border-ink/10 px-3 py-1.5 text-xs font-semibold text-ink">
                        {step.trim()}
                      </span>
                      {i < arr.length - 1 && <span className="text-ink/30">→</span>}
                    </span>
                  ))}
                </div>
              </div>
            </Reveal>

            {/* stats */}
            <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-4">
              {stats.map((s, i) => (
                <Reveal key={s.label} delay={i * 70}>
                  <div className="card-lift rounded-3xl border border-ink/10 bg-paper-card p-5">
                    <div className="font-display text-2xl sm:text-3xl font-extrabold tracking-tight tabular-nums">
                      {s.value}
                    </div>
                    <div className="mt-1 text-xs font-medium leading-snug text-ink-mute">{s.label}</div>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>

          {/* right: elevated profile card */}
          <div className="lg:col-span-5">
            <Reveal delay={120} className="lg:sticky lg:top-28">
              <div className="perspective-1200">
                <div className="relative rotate-1 rounded-[2rem] border border-ink/10 bg-ink p-7 text-paper shadow-deep transition-transform duration-500 hover:rotate-0">
                  <div className="absolute -right-3 -top-3 rounded-full bg-chart px-3.5 py-1.5 font-mono text-[10px] font-bold uppercase tracking-widest text-ink shadow-lift -rotate-3">
                    {profile.status}
                  </div>
                  <Quote className="h-6 w-6 text-chart" />
                  <p className="mt-4 font-serif text-lg leading-relaxed italic text-paper/90">
                    “{profile.quote}”
                  </p>
                  <div className="mt-6 border-t border-paper/15 pt-5">
                    <div className="font-display text-xl font-bold tracking-tight">{profile.name}</div>
                    <div className="mt-1 font-mono text-[11px] uppercase tracking-widest text-chart">
                      {profile.professionalProfile}
                    </div>
                  </div>
                  <dl className="mt-5 space-y-4 text-sm">
                    <div>
                      <dt className="font-mono text-[10px] uppercase tracking-widest text-paper/50">
                        Core Interests
                      </dt>
                      <dd className="mt-1 leading-relaxed text-paper/85">{profile.coreInterests}</dd>
                    </div>
                    <div>
                      <dt className="font-mono text-[10px] uppercase tracking-widest text-paper/50">
                        Working Style
                      </dt>
                      <dd className="mt-1 leading-relaxed text-paper/85">{profile.workingStyle}</dd>
                    </div>
                  </dl>
                </div>
              </div>
            </Reveal>
          </div>
        </div>

        {/* education + certificates */}
        <div className="mt-16 grid grid-cols-1 gap-6 lg:grid-cols-2">
          <Reveal>
            <div className="h-full rounded-[2rem] border border-ink/10 bg-paper-card p-7 sm:p-8 shadow-lift">
              <div className="mb-6 flex items-center gap-2.5">
                <GraduationCap className="h-5 w-5 text-ink" />
                <h3 className="font-display text-xl font-bold tracking-tight">
                  Completed Academic Qualifications
                </h3>
              </div>
              <div className="space-y-5">
                {education.map((ed) => (
                  <div key={ed.school} className="card-lift rounded-3xl border border-ink/10 bg-paper p-5">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-mono text-[10px] font-semibold uppercase tracking-widest text-ink-mute">
                        {ed.level}
                      </span>
                    </div>
                    <h4 className="mt-1.5 font-display text-lg font-bold tracking-tight">{ed.school}</h4>
                    <p className="mt-1 text-sm text-ink-soft">
                      {ed.certificate} — {ed.group}
                    </p>
                    <div className="mt-3 flex flex-wrap gap-1.5">
                      {ed.details.map((d) => (
                        <span
                          key={d}
                          className="rounded-full border border-ink/10 bg-paper-card px-2.5 py-1 text-[11px] font-medium text-ink-soft"
                        >
                          {d}
                        </span>
                      ))}
                      <span className="rounded-full bg-mint px-2.5 py-1 text-[11px] font-bold text-ink">
                        {ed.grade}
                      </span>
                      <span className="rounded-full bg-ink px-2.5 py-1 text-[11px] font-semibold text-paper">
                        {ed.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </Reveal>

          <Reveal delay={100}>
            <div className="h-full rounded-[2rem] border border-ink/10 bg-paper-card p-7 sm:p-8 shadow-lift">
              <div className="mb-6 flex items-center gap-2.5">
                <BadgeCheck className="h-5 w-5 text-ink" />
                <h3 className="font-display text-xl font-bold tracking-tight">
                  Professional Training &amp; Certificates
                </h3>
              </div>
              <div className="space-y-5">
                {certificates.map((c) => (
                  <div key={c.title} className="card-lift rounded-3xl border border-ink/10 bg-paper p-5">
                    <div className="font-mono text-[10px] font-semibold uppercase tracking-widest text-ink-mute">
                      {c.provider}
                    </div>
                    <h4 className="mt-1.5 font-display text-lg font-bold tracking-tight">{c.title}</h4>
                    <p className="mt-1 text-xs font-medium text-ink-soft">
                      {c.tag} • {c.status}
                    </p>
                    <div className="mt-3 flex flex-wrap gap-1.5">
                      {c.coverage.map((t) => (
                        <span
                          key={t}
                          className="rounded-full border border-ink/10 bg-paper-card px-2.5 py-1 text-[11px] font-medium text-ink-soft"
                        >
                          {t}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
