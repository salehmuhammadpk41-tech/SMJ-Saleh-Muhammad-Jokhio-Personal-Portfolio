import { useState, type FormEvent } from 'react';
import { ArrowUpRight, Clock, Copy, Check, Facebook, Linkedin, Mail, Timer } from 'lucide-react';
import { Kicker } from '../components/Kicker';
import { Reveal } from '../components/Reveal';
import { contact, contactSubjects } from '../data/content';

function CopyEmail({ email, label }: { email: string; label: string }) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(email);
    } catch {
      /* clipboard unavailable */
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };
  return (
    <div>
      <span className="mb-1 block font-mono text-[10px] font-semibold uppercase tracking-widest text-chart">
        {label}
      </span>
      <div className="flex flex-wrap items-center justify-between gap-2">
        <a
          href={`mailto:${email}`}
          className="break-all text-sm sm:text-base font-bold text-paper transition-colors hover:text-chart"
        >
          {email}
        </a>
        <button
          onClick={copy}
          className="inline-flex min-h-[32px] items-center gap-1.5 rounded-full border border-paper/20 bg-paper/10 px-3 py-1 text-[11px] font-semibold text-paper/80 transition-colors hover:bg-paper/20 cursor-pointer"
        >
          {copied ? <Check className="h-3 w-3 text-chart" /> : <Copy className="h-3 w-3" />}
          {copied ? 'Copied' : 'Copy'}
        </button>
      </div>
    </div>
  );
}

export function Contact() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState(contactSubjects[0]);
  const [message, setMessage] = useState('');

  const submit = (e: FormEvent) => {
    e.preventDefault();
    const body = encodeURIComponent(
      `Hi Saleh,\n\n${message}\n\n— ${name}${email ? ` (${email})` : ''}`
    );
    window.location.href = `mailto:${contact.primaryEmail}?subject=${encodeURIComponent(
      `Project Inquiry — ${subject}`
    )}&body=${body}`;
  };

  return (
    <section id="contact" className="relative bg-ink px-4 py-20 text-paper sm:px-8 sm:py-28">
      <div className="mx-auto max-w-6xl">
        <div className="grid grid-cols-1 items-start gap-12 lg:grid-cols-12">
          {/* left: info */}
          <div className="lg:col-span-5">
            <Reveal>
              <Kicker text="Let’s connect • Contact" dark />
            </Reveal>
            <Reveal delay={60}>
              <h2 className="mt-6 text-balance font-display text-4xl font-extrabold leading-[1.06] tracking-[-0.025em] sm:text-5xl">
                Have an <em className="font-serif font-normal italic text-chart">Idea</em> in Mind?
              </h2>
              <p className="mt-4 max-w-md text-[15px] leading-relaxed text-paper/75">
                Whether you’re planning a digital project, exploring a new idea, or simply have a
                question, I’m always open to connecting. Let’s start a conversation and explore
                what we can create together.
              </p>
            </Reveal>

            <Reveal delay={120}>
              <div className="mt-8 space-y-5 rounded-3xl border border-paper/15 bg-paper/5 p-6">
                <CopyEmail email={contact.primaryEmail} label={contact.primaryLabel} />
                <div className="border-t border-paper/10 pt-5">
                  <CopyEmail email={contact.alternateEmail} label={contact.alternateLabel} />
                </div>
              </div>
            </Reveal>

            <Reveal delay={160}>
              <div className="mt-5 grid grid-cols-2 gap-3">
                <div className="rounded-3xl border border-paper/15 bg-paper/5 p-4">
                  <div className="mb-1 flex items-center gap-1.5 text-xs text-paper/60">
                    <Clock className="h-3.5 w-3.5 text-chart" /> Contact Hours
                  </div>
                  <div className="text-sm font-bold">{contact.hours}</div>
                </div>
                <div className="rounded-3xl border border-paper/15 bg-paper/5 p-4">
                  <div className="mb-1 flex items-center gap-1.5 text-xs text-paper/60">
                    <Timer className="h-3.5 w-3.5 text-chart" /> Typical Response
                  </div>
                  <div className="text-sm font-bold">{contact.response}</div>
                </div>
              </div>
            </Reveal>

            <Reveal delay={200}>
              <div className="mt-6 flex flex-wrap items-center gap-2.5">
                <a
                  href={contact.facebook}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex min-h-[40px] items-center gap-2 rounded-full border border-paper/15 bg-paper/5 px-4 py-2 text-[13px] font-semibold transition-colors hover:bg-paper/15"
                >
                  <Facebook className="h-3.5 w-3.5 text-chart" /> Facebook
                </a>
                <a
                  href={contact.linkedin}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex min-h-[40px] items-center gap-2 rounded-full border border-paper/15 bg-paper/5 px-4 py-2 text-[13px] font-semibold transition-colors hover:bg-paper/15"
                >
                  <Linkedin className="h-3.5 w-3.5 text-chart" /> LinkedIn
                </a>
                <a
                  href={`mailto:${contact.primaryEmail}`}
                  className="inline-flex min-h-[40px] items-center gap-2 rounded-full border border-paper/15 bg-paper/5 px-4 py-2 text-[13px] font-semibold transition-colors hover:bg-paper/15"
                >
                  <Mail className="h-3.5 w-3.5 text-chart" /> Email
                </a>
              </div>
            </Reveal>
          </div>

          {/* right: form */}
          <Reveal delay={120} className="lg:col-span-7">
            <form
              onSubmit={submit}
              className="rounded-[2rem] border border-ink/10 bg-paper-card p-7 text-ink shadow-deep sm:p-9"
            >
              <h3 className="font-display text-2xl font-bold tracking-tight">Send a Direct Message</h3>
              <p className="mt-1.5 text-sm text-ink-soft">
                Share your project goals, questions, or ideas. Saleh will review your message
                personally.
              </p>

              <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2">
                <label className="block">
                  <span className="mb-1.5 block font-mono text-[10px] font-semibold uppercase tracking-widest text-ink-mute">
                    Your Name
                  </span>
                  <input
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Full name"
                    className="min-h-[46px] w-full rounded-2xl border border-ink/15 bg-paper px-4 text-sm outline-none transition-shadow focus:shadow-[0_0_0_3px_rgba(200,245,71,0.6)]"
                  />
                </label>
                <label className="block">
                  <span className="mb-1.5 block font-mono text-[10px] font-semibold uppercase tracking-widest text-ink-mute">
                    Your Email
                  </span>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@email.com"
                    className="min-h-[46px] w-full rounded-2xl border border-ink/15 bg-paper px-4 text-sm outline-none transition-shadow focus:shadow-[0_0_0_3px_rgba(200,245,71,0.6)]"
                  />
                </label>
              </div>

              <label className="mt-4 block">
                <span className="mb-1.5 block font-mono text-[10px] font-semibold uppercase tracking-widest text-ink-mute">
                  Project Type
                </span>
                <select
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  className="min-h-[46px] w-full rounded-2xl border border-ink/15 bg-paper px-4 text-sm outline-none transition-shadow focus:shadow-[0_0_0_3px_rgba(200,245,71,0.6)]"
                >
                  {contactSubjects.map((s) => (
                    <option key={s}>{s}</option>
                  ))}
                </select>
              </label>

              <label className="mt-4 block">
                <span className="mb-1.5 block font-mono text-[10px] font-semibold uppercase tracking-widest text-ink-mute">
                  Message
                </span>
                <textarea
                  required
                  rows={5}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Tell me about your idea, goals, or questions…"
                  className="w-full resize-y rounded-2xl border border-ink/15 bg-paper px-4 py-3 text-sm outline-none transition-shadow focus:shadow-[0_0_0_3px_rgba(200,245,71,0.6)]"
                />
              </label>

              <button
                type="submit"
                className="btn-arrow mt-6 inline-flex min-h-[48px] w-full items-center justify-center gap-2.5 rounded-full bg-ink px-7 py-3 text-sm font-semibold text-paper transition-all duration-300 hover:bg-transparent hover:text-ink hover:shadow-[inset_0_0_0_1.5px_#0e2a22] cursor-pointer sm:w-auto"
              >
                Send Message
                <span className="relative inline-flex h-4 w-4 overflow-hidden">
                  <ArrowUpRight className="arrow-main h-4 w-4" />
                  <ArrowUpRight className="arrow-clone h-4 w-4" />
                </span>
              </button>
            </form>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
