import { useState } from 'react';
import { ShieldCheck, Wrench } from 'lucide-react';
import { Kicker } from '../components/Kicker';
import { Reveal } from '../components/Reveal';
import { skills, tools, strengths } from '../data/content';

type Tab = 'technical' | 'tools';

export function Skills() {
  const [tab, setTab] = useState<Tab>('technical');

  return (
    <section id="skills" className="relative px-4 py-20 sm:px-8 sm:py-28">
      <div className="mx-auto max-w-6xl">
        <Reveal>
          <Kicker text="Verified Capabilities" />
        </Reveal>
        <div className="mt-6 flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
          <Reveal delay={60}>
            <h2 className="max-w-xl text-balance font-display text-4xl font-extrabold leading-[1.06] tracking-[-0.025em] sm:text-5xl">
              Technical &amp; <em className="font-serif font-normal italic">Professional</em> Skills
            </h2>
            <p className="mt-4 max-w-lg text-[15px] leading-relaxed text-ink-soft">
              Rigorous foundations across web technologies, digital productivity suites, and modern
              AI workflows.
            </p>
          </Reveal>
          <Reveal delay={120}>
            {/* pill tab container */}
            <div className="inline-flex rounded-full border border-ink/15 bg-paper-card p-1 shadow-lift">
              {(
                [
                  { id: 'technical', label: 'Technical Skills', icon: ShieldCheck },
                  { id: 'tools', label: 'AI Workflow Tools', icon: Wrench },
                ] as const
              ).map((t) => (
                <button
                  key={t.id}
                  onClick={() => setTab(t.id)}
                  className={`inline-flex min-h-[40px] items-center gap-2 rounded-full px-4 sm:px-5 text-[13px] font-semibold transition-all duration-200 cursor-pointer ${
                    tab === t.id ? 'bg-ink text-paper' : 'text-ink-soft hover:text-ink'
                  }`}
                >
                  <t.icon className="h-3.5 w-3.5" />
                  {t.label}
                </button>
              ))}
            </div>
          </Reveal>
        </div>

        {tab === 'technical' ? (
          <div className="mt-10 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {skills.map((s, i) => (
              <Reveal key={s.num} delay={(i % 4) * 60}>
                <div className="card-lift group h-full rounded-3xl border border-ink/10 bg-paper-card p-6">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-semibold text-ink-mute">{s.num}</span>
                    <span className="rounded-full border border-ink/10 bg-mint/60 px-2 py-0.5 text-[10px] font-bold text-ink">
                      Practical • Verified
                    </span>
                  </div>
                  <h3 className="mt-4 font-display text-lg font-bold tracking-tight">{s.name}</h3>
                  <p className="mt-2 text-[13px] leading-relaxed text-ink-soft">{s.desc}</p>
                </div>
              </Reveal>
            ))}
          </div>
        ) : (
          <div className="mt-10 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {tools.map((t, i) => (
              <Reveal key={t.num} delay={(i % 3) * 60}>
                <div className="card-lift h-full rounded-3xl border border-ink/10 bg-paper-card p-6">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-mono text-[10px] font-semibold uppercase tracking-widest text-ink-mute">
                      {t.category}
                    </span>
                    <span className="rounded-full border border-ink/10 bg-chart/70 px-2 py-0.5 text-[10px] font-bold text-ink">
                      Active • Workflow
                    </span>
                  </div>
                  <h3 className="mt-4 font-display text-lg font-bold tracking-tight">{t.name}</h3>
                  <p className="mt-2 text-[13px] leading-relaxed text-ink-soft">{t.role}</p>
                </div>
              </Reveal>
            ))}
          </div>
        )}

        <Reveal delay={80}>
          <div className="mt-10 rounded-[2rem] border border-ink/10 bg-paper-card p-7 shadow-lift">
            <div className="mb-4 font-mono text-[11px] font-semibold uppercase tracking-widest text-ink-mute">
              Professional Strengths &amp; Character
            </div>
            <div className="flex flex-wrap gap-2">
              {strengths.map((s) => (
                <span
                  key={s}
                  className="rounded-full border border-ink/10 bg-paper px-3.5 py-1.5 text-xs font-semibold text-ink transition-colors duration-200 hover:bg-chart"
                >
                  {s}
                </span>
              ))}
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
