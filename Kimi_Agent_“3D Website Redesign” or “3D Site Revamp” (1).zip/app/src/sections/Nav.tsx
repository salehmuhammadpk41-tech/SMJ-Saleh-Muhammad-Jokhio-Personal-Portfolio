import { useEffect, useRef, useState } from 'react';
import { Menu, X, ArrowUpRight } from 'lucide-react';
import { navItems, profile } from '../data/content';

export function Nav() {
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState('home');
  const [scrolled, setScrolled] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 24);
      let current = 'home';
      for (const item of navItems) {
        const el = document.getElementById(item.id);
        if (el && el.getBoundingClientRect().top <= window.innerHeight * 0.4) {
          current = item.id;
        }
      }
      setActive(current);
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false);
    const onResize = () => window.innerWidth >= 768 && setOpen(false);
    const onDown = (e: MouseEvent) => {
      if (open && menuRef.current && !menuRef.current.contains(e.target as Node)) setOpen(false);
    };
    window.addEventListener('keydown', onKey);
    window.addEventListener('resize', onResize);
    document.addEventListener('mousedown', onDown);
    return () => {
      window.removeEventListener('keydown', onKey);
      window.removeEventListener('resize', onResize);
      document.removeEventListener('mousedown', onDown);
    };
  }, [open]);

  const go = (id: string) => {
    setOpen(false);
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <header className="fixed inset-x-0 top-3 sm:top-5 z-50 flex justify-center px-3 sm:px-6">
      <div ref={menuRef} className="w-full max-w-3xl">
        <nav
          className={`flex items-center justify-between gap-2 rounded-full border border-ink/10 bg-paper-card/90 py-2 pl-5 pr-2 backdrop-blur-xl transition-shadow duration-300 ${
            scrolled ? 'shadow-lift' : 'shadow-none'
          }`}
        >
          <button
            onClick={() => go('home')}
            className="flex items-center gap-2 font-display text-sm sm:text-[15px] font-bold tracking-tight cursor-pointer"
            aria-label="Go to home"
          >
            <span className="flex h-6 w-6 items-center justify-center rounded-full bg-ink font-mono text-[11px] font-semibold text-chart">
              S
            </span>
            {profile.shortName}
          </button>

          {/* desktop links */}
          <div className="hidden md:flex items-center gap-0.5">
            {navItems.slice(1, 6).map((item) => (
              <button
                key={item.id}
                onClick={() => go(item.id)}
                className={`rounded-full px-3.5 py-1.5 text-[13px] font-medium transition-colors duration-200 cursor-pointer ${
                  active === item.id
                    ? 'bg-ink text-paper'
                    : 'text-ink-soft hover:text-ink hover:bg-ink/[0.05]'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => go('contact')}
              className="btn-arrow group relative hidden sm:inline-flex items-center gap-2 overflow-hidden rounded-full bg-ink px-5 py-2 text-[13px] font-semibold text-paper transition-colors duration-300 hover:bg-transparent hover:text-ink hover:shadow-[inset_0_0_0_1.5px_#0e2a22] cursor-pointer"
            >
              Contact
              <span className="relative inline-flex h-3.5 w-3.5 overflow-hidden">
                <ArrowUpRight className="arrow-main h-3.5 w-3.5" />
                <ArrowUpRight className="arrow-clone h-3.5 w-3.5" />
              </span>
            </button>
            <button
              onClick={() => setOpen((v) => !v)}
              className="md:hidden flex h-9 w-9 items-center justify-center rounded-full border border-ink/10 bg-paper text-ink cursor-pointer"
              aria-label={open ? 'Close menu' : 'Open menu'}
              aria-expanded={open}
            >
              {open ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
            </button>
          </div>
        </nav>

        {/* mobile menu */}
        <div
          className={`md:hidden overflow-hidden rounded-3xl border border-ink/10 bg-paper-card/95 backdrop-blur-xl transition-all duration-300 shadow-lift ${
            open ? 'mt-2 max-h-96 opacity-100' : 'mt-0 max-h-0 opacity-0 border-transparent'
          }`}
        >
          <div className="flex flex-col p-2">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => go(item.id)}
                className={`rounded-2xl px-4 py-3 text-left text-sm font-medium transition-colors cursor-pointer ${
                  active === item.id ? 'bg-ink text-paper' : 'text-ink hover:bg-ink/[0.05]'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>
      </div>
    </header>
  );
}
