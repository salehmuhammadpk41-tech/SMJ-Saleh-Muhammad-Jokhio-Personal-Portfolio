import { ArrowUpRight } from 'lucide-react';
import { Reveal } from '../components/Reveal';
import { Sticker } from '../components/Sticker';

export function CtaBanner() {
  const go = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });

  return (
    <section className="px-4 pb-20 sm:px-8 sm:pb-28">
      <div className="mx-auto max-w-6xl">
        <Reveal>
          <div className="relative overflow-hidden rounded-[2.5rem] bg-ink px-7 py-12 text-paper shadow-deep sm:px-12 sm:py-16">
            {/* layered depth accents */}
            <div className="pointer-events-none absolute -right-16 -top-16 h-56 w-56 rounded-full bg-chart/15 blur-2xl" />
            <div className="pointer-events-none absolute -bottom-20 -left-10 h-56 w-56 rounded-full bg-mint/10 blur-2xl" />

            <div className="relative grid grid-cols-1 items-center gap-10 lg:grid-cols-12">
              <div className="lg:col-span-8">
                <span className="font-mono text-[11px] font-semibold uppercase tracking-widest text-chart">
                  Ready to create?
                </span>
                <h3 className="mt-3 text-balance font-display text-3xl font-extrabold leading-[1.08] tracking-[-0.02em] sm:text-4xl">
                  Start With an Idea.{' '}
                  <em className="font-serif font-normal italic text-chart">Build Something Meaningful.</em>
                </h3>
                <p className="mt-4 max-w-xl text-[15px] leading-relaxed text-paper/75">
                  Have an idea you want to explore? From websites and digital tools to UI/UX,
                  creative designs, coding projects, and custom digital solutions, let’s turn your
                  concept into something practical and useful.
                </p>
                <button
                  onClick={() => go('contact')}
                  className="btn-arrow mt-7 inline-flex min-h-[46px] items-center gap-2.5 rounded-full bg-chart px-7 py-3 text-sm font-bold text-ink transition-transform duration-200 hover:scale-[1.03] cursor-pointer"
                >
                  Start your project
                  <span className="relative inline-flex h-4 w-4 overflow-hidden">
                    <ArrowUpRight className="arrow-main h-4 w-4" />
                    <ArrowUpRight className="arrow-clone h-4 w-4" />
                  </span>
                </button>
              </div>
              <div className="hidden lg:col-span-4 lg:flex lg:justify-center">
                <div className="animate-floaty" style={{ '--float-dur': '6.5s' } as React.CSSProperties}>
                  <Sticker text="IDEAS INTO DIGITAL EXPERIENCES • " className="h-36 w-36 drop-shadow-2xl" />
                </div>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
