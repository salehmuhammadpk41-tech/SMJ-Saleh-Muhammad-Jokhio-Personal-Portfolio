import { ArrowUpRight } from 'lucide-react';
import { Kicker } from '../components/Kicker';
import { Reveal } from '../components/Reveal';
import { projects } from '../data/content';

const previewTones: Record<string, { bg: string; accent: string; dark: boolean }> = {
  vaultkey: { bg: 'bg-ink', accent: 'bg-chart', dark: true },
  toolhub: { bg: 'bg-mint', accent: 'bg-ink', dark: false },
  smj: { bg: 'bg-brick', accent: 'bg-ink', dark: false },
};

/** Code-drawn abstract browser preview sitting in 3D space. */
function Preview({ id, title }: { id: string; title: string }) {
  const tone = previewTones[id];
  return (
    <div className="perspective-1200 relative h-48 sm:h-52 overflow-hidden rounded-t-3xl border-b border-ink/10 bg-paper-2">
      <div
        className={`preserve-3d absolute left-1/2 top-1/2 w-[78%] -translate-x-1/2 -translate-y-1/2 rotate-x-6 transition-transform duration-500 ease-out group-hover:-translate-y-[54%] group-hover:rotate-0`}
      >
        <div className={`rounded-2xl p-3 shadow-float ${tone.bg}`}>
          <div className="mb-2.5 flex items-center gap-1.5">
            <span className={`h-2 w-2 rounded-full ${tone.dark ? 'bg-paper/30' : 'bg-ink/20'}`} />
            <span className={`h-2 w-2 rounded-full ${tone.dark ? 'bg-paper/30' : 'bg-ink/20'}`} />
            <span className={`h-2 w-2 rounded-full ${tone.dark ? 'bg-paper/30' : 'bg-ink/20'}`} />
            <span
              className={`ml-2 h-4 flex-1 rounded-full ${tone.dark ? 'bg-paper/10' : 'bg-ink/10'}`}
            />
          </div>
          <div className={`rounded-xl p-4 ${tone.dark ? 'bg-paper/10' : 'bg-paper-card'}`}>
            <div className={`h-3 w-2/5 rounded-full ${tone.accent}`} />
            <div className="mt-2.5 space-y-1.5">
              <div className={`h-1.5 w-4/5 rounded-full ${tone.dark ? 'bg-paper/25' : 'bg-ink/15'}`} />
              <div className={`h-1.5 w-3/5 rounded-full ${tone.dark ? 'bg-paper/25' : 'bg-ink/15'}`} />
            </div>
            <div className="mt-3.5 flex gap-2">
              <div className={`h-6 w-16 rounded-full ${tone.accent}`} />
              <div
                className={`h-6 w-16 rounded-full border ${
                  tone.dark ? 'border-paper/30' : 'border-ink/20'
                }`}
              />
            </div>
          </div>
        </div>
        <span className="sr-only">{title} preview</span>
      </div>
    </div>
  );
}

export function Projects() {
  return (
    <section id="projects" className="relative px-4 py-20 sm:px-8 sm:py-28">
      <div className="mx-auto max-w-6xl">
        <Reveal>
          <Kicker text="Selected Work • Portfolio" />
        </Reveal>
        <Reveal delay={60}>
          <h2 className="mt-6 max-w-2xl text-balance font-display text-4xl font-extrabold leading-[1.06] tracking-[-0.025em] sm:text-5xl">
            Digital Work, <em className="font-serif font-normal italic">Built With Purpose</em>
          </h2>
          <p className="mt-4 max-w-xl text-[15px] leading-relaxed text-ink-soft">
            A collection of websites, digital tools, creative interfaces, experiments, and practical
            projects shaped through design, technology, and continuous learning. Explore the work,
            ideas, and digital experiences created by{' '}
            <strong className="font-semibold text-ink">Saleh Muhammad Jokhio</strong>.
          </p>
        </Reveal>

        <div className="mt-12 grid grid-cols-1 gap-6 md:grid-cols-3">
          {projects.map((p, i) => (
            <Reveal key={p.id} delay={i * 90}>
              <article className="card-lift group flex h-full flex-col overflow-hidden rounded-3xl border border-ink/10 bg-paper-card">
                <Preview id={p.id} title={p.title} />
                <div className="flex flex-1 flex-col p-6">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-mono text-[10px] font-semibold uppercase tracking-widest text-ink-mute">
                      {p.num} — {p.category}
                    </span>
                  </div>
                  <h3 className="mt-2.5 font-display text-2xl font-bold tracking-tight">{p.title}</h3>
                  <p className="mt-1 font-serif text-[15px] italic text-ink">{p.tagline}</p>
                  <p className="mt-2.5 flex-1 text-[13px] leading-relaxed text-ink-soft">{p.desc}</p>
                  <a
                    href={p.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn-arrow mt-5 inline-flex min-h-[42px] items-center justify-center gap-2 rounded-full bg-ink px-5 py-2.5 text-[13px] font-semibold text-paper transition-all duration-300 hover:bg-transparent hover:text-ink hover:shadow-[inset_0_0_0_1.5px_#0e2a22]"
                  >
                    Visit Website
                    <span className="relative inline-flex h-3.5 w-3.5 overflow-hidden">
                      <ArrowUpRight className="arrow-main h-3.5 w-3.5" />
                      <ArrowUpRight className="arrow-clone h-3.5 w-3.5" />
                    </span>
                  </a>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
