import { Nav } from './sections/Nav';
import { Hero } from './sections/Hero';
import { About } from './sections/About';
import { Skills } from './sections/Skills';
import { Services } from './sections/Services';
import { Process } from './sections/Process';
import { CtaBanner } from './sections/CtaBanner';
import { Projects } from './sections/Projects';
import { Contact } from './sections/Contact';
import { Footer } from './sections/Footer';

function App() {
  return (
    <div className="min-h-screen bg-paper text-ink antialiased">
      <Nav />
      <main>
        <Hero />
        {/* alternating soft bands keep the single-column rhythm readable */}
        <div className="border-t border-ink/5 bg-paper-card/60">
          <About />
        </div>
        <div className="border-t border-ink/5">
          <Skills />
        </div>
        <div className="border-t border-ink/5 bg-paper-card/60">
          <Services />
        </div>
        <div className="border-t border-ink/5">
          <Process />
        </div>
        <CtaBanner />
        <div className="border-t border-ink/5 bg-paper-card/60">
          <Projects />
        </div>
        <Contact />
      </main>
      <Footer />
    </div>
  );
}

export default App;
